const resultEl = document.getElementById('result')
const lengthEl = document.getElementById('length')
const uppercaseEl = document.getElementById('uppercase')
const lowercaseEl = document.getElementById('lowercase')
const numbersEl = document.getElementById('numbers')
const symbolsEl = document.getElementById('symbols')
const generateEl = document.getElementById('generate')
const clipboardEl = document.getElementById('clipboard')

const randomFunc = {
    lower: getRandomLower,
    upper: getRandomUpper,
    number: getRandomNumber,
    symbol: getRandomSymbol
}

clipboardEl.addEventListener('click', () => {
  navigator.clipboard.writeText(resultEl.innerHTML);
  alert("Copied the text: " + resultEl.innerHTML);
})

generateEl.addEventListener('click', () => {
    const length = lengthEl.value
    resultEl.innerHTML = generatePassword(length)
})

function generatePassword(length) {
    let password = "";
    var i = 0;
    while(i < length){
        password += getRandomUpper();
        password += getRandomLower();
        password += getRandomSymbol();
        password += getRandomNumber();
        i = i+4;
    }
    return password;
}

function getRandomLower() {
  const alphabet = "abcdefghijklmnopqrstuvwxyz"

  return alphabet[Math.floor(Math.random() * alphabet.length)]
}

function getRandomUpper() {
  const alphabet = "abcdefghijklmnopqrstuvwxyz"
  alphabet.toUpperCase()
  return alphabet[Math.floor(Math.random() * alphabet.length)]
}

function getRandomNumber() {
    return Math.floor(Math.random() * 10);
}

function getRandomSymbol() {
    const symbol = "$#@%&*_-~"
    return symbol[Math.floor(Math.random() * symbol.length)]
}