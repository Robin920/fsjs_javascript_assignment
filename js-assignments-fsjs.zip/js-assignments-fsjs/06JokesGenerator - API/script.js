let punchline = document.querySelector("#joke");
let callBtn = document.querySelector("#jokeBtn");
let setup = document.querySelector("#setup");

const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '1129d7dc41msh527f8585a05bf53p1cefd7jsna4deb07869f3',
		'X-RapidAPI-Host': 'dad-jokes.p.rapidapi.com'
	}
};

function setVal(joke) {
    punchline.innerHTML = joke.punchline;
    setup.innerHTML = joke.setup;
}

callBtn.addEventListener('click', () => {
    fetch('https://dad-jokes.p.rapidapi.com/random/joke', options)
	.then(response => response.json())
	.then(response => setVal(response.body[0]))
	.catch(err => console.error(err));
})