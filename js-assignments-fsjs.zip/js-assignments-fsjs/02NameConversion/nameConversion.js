document.getElementById('convert-btn').addEventListener('click',setVal);
function camelCase(str){
    return str.split(' ').map(function(word,index){
        // If it is the first word make sure to lowercase all the chars.
        if(index == 0){
          return word.toLowerCase();
        }
        // If it is not the first word only upper case the first char and lowercase the rest.
        return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
      }).join('');
}

function pascalCase(str){
    return str.split(' ').map(function(word){
       return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
      }).join('');
}

function snakeCase(str){
    return str.split(' ').map(function(word){
       return word.toLowerCase();
      }).join('_');
}
function screamingSnakeCase(str){
    return str.split(' ').map(function(word){
       return word.toUpperCase();
      }).join('_');
}

function kebabCase(str){
    return str.split(' ').map(function(word){
       return word.toLowerCase();
      }).join('-');
}
function screamingKebabCase(str){
    return str.split(' ').map(function(word){
       return word.toUpperCase();
      }).join('-');
}

function setVal() {
    var input = document.querySelector("#text").value;
    document.getElementById('camel-case').innerHTML = camelCase(input);
    document.getElementById('pascal-case').innerHTML = pascalCase(input);
    document.getElementById('snake-case').innerHTML = snakeCase(input);
    document.getElementById('screaming-snake-case').innerHTML = screamingSnakeCase(input);
    document.getElementById('kebab-case').innerHTML = kebabCase(input);
    document.getElementById('screaming-kebab-case').innerHTML = screamingKebabCase(input);
}