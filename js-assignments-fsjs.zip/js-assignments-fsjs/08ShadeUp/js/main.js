function randompickerbtn() {
    const randomColor = Math.floor(Math.random()*16777215).toString(16);
    document.body.style.backgroundColor = "#" + randomColor;
    document.querySelector("#randomPicker").style.backgroundColor = "#" + randomColor;
    document.querySelector("#randomValuePara").innerHTML = "#" + randomColor;
  }

function hexFindbtn() {
    let hex = document.querySelector("#hexInput").value;
    document.querySelector("#color-box").style.backgroundColor = hex;
}

function RGBFindbtn() {
  let red = document.querySelector("#RInput").value;
  let green = document.querySelector("#GInput").value;
  let blue = document.querySelector("#BInput").value;
  document.querySelector("#rgb-color-box").style.backgroundColor = `rgb(${red}, ${green}, ${blue})`
}

function RangeSelector() {
  let red = document.querySelector("#RrInput").value;
  let green = document.querySelector("#GrInput").value;
  let blue = document.querySelector("#BrInput").value;

  document.querySelector("#range-color-box").style.backgroundColor = `rgb(${red}, ${green}, ${blue})`
}

// hex to rgb converter

String.prototype.convertToRGB = function () {
  
};

const rgbToHex = (r, g, b) => '#' + [r, g, b].map(x => {
    const hex = x.toString(16)
    return hex.length === 1 ? '0' + hex : hex
  }).join('')

function rgbConvbtn(){
    let red = parseInt(document.querySelector("#RCInput").value);
    let green = parseInt(document.querySelector("#GCInput").value);
    let blue = parseInt(document.querySelector("#BCInput").value);
    let res = rgbToHex(red, green, blue);
    document.querySelector("#rgbCOut").innerHTML = res;
}

const hexToRgb = hex =>
  hex.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i
             ,(m, r, g, b) => '#' + r + r + g + g + b + b)
    .substring(1).match(/.{2}/g)
    .map(x => parseInt(x, 16))

function hexConvbtn(){
    let hex = document.querySelector("#hexCInp").value
    document.querySelector("#hexCOut").innerHTML = `rgb(${hexToRgb(hex)})`
}


