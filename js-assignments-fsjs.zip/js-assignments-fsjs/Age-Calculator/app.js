const container = document.querySelector("#dob");
const error = document.querySelector(".error");

container.addEventListener('input', getAge)
function getAge(){
    let bday = container.value;
    calcAge(bday)
}

function calcAge(bday){ 
    let now = new Date();
    let year = now.getFullYear();
    let month = now.getMonth()+1;
    let day = now.getDate();  
    
    let barr = bday.split("-");
    let yr = year - barr[0];
    let mn = month - barr[1];
    let da = day - barr[2];
    displayAge(yr, mn, da)
}

function displayAge(yr, mn, da){
    document.querySelector("#years").innerHTML = yr;
    document.querySelector("#months").innerHTML = mn;
    document.querySelector("#days").innerHTML = da;

    if(yr < 0){
        error.style.display = "block";
    }
}

