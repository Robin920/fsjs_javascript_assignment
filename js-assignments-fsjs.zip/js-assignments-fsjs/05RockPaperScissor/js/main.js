let user = document.querySelector("#result-user-stat");
let comp = document.querySelector("#result-comp-stat");
let result = document.querySelector("#result-final-stat");
let userScore = document.querySelector("#userScoreVal");
let compScore = document.querySelector("#compScoreVal");

let rock = document.querySelector("#r");
let paper = document.querySelector("#p");
let scissor = document.querySelector("#s");
var uScore = 0;
var cScore = 0;

function count(){
    if(result.innerHTML == "COMP"){
        cScore++;
        compScore.innerHTML = cScore;
    }
    else if(result.innerHTML == "USER"){
        uScore++;
        userScore.innerHTML = uScore;
    }
}

function winner(userPlay, compPlay){
    if(userPlay == compPlay){
       return "Tied";
    }
    else if(userPlay == "Rock" && compPlay == "Paper"){
        return "COMP"
    }
    else if(userPlay == "Paper" && compPlay == "Rock"){
        return "USER"
    }
    else if(userPlay == "Paper" && compPlay == "Scissors"){
        return "COMP"
    }
    else if(userPlay == "Scissors" && compPlay == "Paper"){
        return "USER"
    }
    else if(userPlay == "Scissors" && compPlay == "Rock"){
        return "COMP"
    }
    else if(userPlay == "Rock" && compPlay == "Scissors"){
        return "USER"
    }
}
function randomPlay(){
    let arr = ['Rock','Paper','Scissors'];
    return arr[Math.floor(Math.random()*arr.length)];
}

rock.addEventListener('click', () => {
    let userPlay = "Rock";
    let compPlay = randomPlay();
    user.innerHTML = userPlay;
    comp.innerHTML = compPlay;
    result.innerHTML = winner(userPlay, compPlay);
    count();
})
paper.addEventListener('click', () => {
    let userPlay = "Paper";
    let compPlay = randomPlay();
    user.innerHTML = userPlay;
    comp.innerHTML = compPlay;
    result.innerHTML = winner(userPlay, compPlay);
    count();
})
scissor.addEventListener('click', () => {
    let userPlay = "Scissors";
    let compPlay = randomPlay();
    user.innerHTML = userPlay;
    comp.innerHTML = compPlay;
    result.innerHTML = winner(userPlay, compPlay);
    count();
})