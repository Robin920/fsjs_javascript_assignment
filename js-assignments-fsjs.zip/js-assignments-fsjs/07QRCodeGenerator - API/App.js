let qr = document.querySelector("#img");
let btn = document.querySelector("#submit");
let input = document.querySelector("#input");
var parametersJson = {
	"size": 250, // Size of Qr Code
	"backgroundColor": "255-255-255", // Background Color Of Qr Code (In RGB)
	"qrColor": "38-38-38", // Color of Qr Code (In RGB)
	"padding": 1, // Padding 
	"data": "dewangqr"
};
var parameters;

btn.addEventListener('click', function(){
	parametersJson.data = input.value || "qr";
	parameters = `size=${parametersJson.size}&bgcolor=${parametersJson.backgroundColor}&color=${parametersJson.qrColor}&qzone=${parametersJson.padding}&data=${parametersJson.data}` // Stitch Together all Paramenters
	img.src = `https://api.qrserver.com/v1/create-qr-code/?${parameters}` // Set Image URL To Link
})