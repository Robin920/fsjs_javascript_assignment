
function insert(num){
  }
  
  function equals(){
    
      
  }
  
  function clean(){
  }
  
  function back(){
  }