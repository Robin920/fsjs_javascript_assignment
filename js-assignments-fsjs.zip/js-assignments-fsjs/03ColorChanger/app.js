var color = document.querySelector("#canvas")

var btn = document.querySelector("#button")
btn.addEventListener('click',changeColor)

function changeColor() {
    var randomColor = Math.floor(Math.random()*16777215).toString(16);
    color.style.backgroundColor = "#"+randomColor;
}